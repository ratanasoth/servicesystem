<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <strong>Edit Asset</strong>&nbsp;&nbsp;
                    <a href="<?php echo e(url('/asset/create')); ?>"><i class="fa fa-plus"></i> New</a>
                    <a href="<?php echo e(url('/asset')); ?>" class="text-success"><i class="fa fa-arrow-left"></i> Back</a>

                </div>
                <div class="card-block">
                    <?php if(Session::has('sms')): ?>
                        <div class="alert alert-success" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <div>
                                <?php echo e(session('sms')); ?>

                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if(Session::has('sms1')): ?>
                        <div class="alert alert-danger" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <div>
                                <?php echo e(session('sms1')); ?>

                            </div>
                        </div>
                    <?php endif; ?>
                    <form action="<?php echo e(url('/asset/update')); ?>" class="form-horizontal" method="post" onsubmit="return confirm('Are you sure want to save?')">
                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <input type="hidden" value="<?php echo e($assets->id); ?>" name="id">
                            <div class="col-sm-6">
                                <div class="form-group row">
                                    <label for="name" class="control-label col-sm-3 lb"> Name<span class="text-danger">*</span></label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" value="<?php echo e($assets->name); ?>" name="name" id="name" required>

                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="reference" class="control-label col-sm-3 lb"> Reference Code</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" value="<?php echo e($assets->reference_code); ?>" name="reference" id="reference">
                                    </div>
                                </div>
                              
                                <div class="form-group row">
                                    <label for="type" class="control-label col-sm-3 lb">Asset Type<span class="text-danger">*</span></label>
                                    <div class="col-sm-8">
                                        <select name="type" id="type" class="form-control" required="true">
                                            <option value="">--Please Select--</option>
                                            <?php $__currentLoopData = $asset_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php echo e($assets->type_id==$asset_type->id?'selected':''); ?> value="<?php echo e($asset_type->id); ?>"><?php echo e($asset_type->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="warehouse" class="control-label col-sm-3 lb">Warehouse<span class="text-danger">*</span></label>
                                    <div class="col-sm-8">
                                        <select name="warehouse" id="warehouse" class="form-control" required="true">
                                            <option value="">--Please Select--</option>
                                            <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php echo e($assets->type_id==$warehouse->id?'selected':''); ?> value="<?php echo e($warehouse->id); ?>"><?php echo e($warehouse->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="total" class="control-label col-sm-3 lb">Total Qty</label>
                                    <div class="col-sm-8">
                                        <input type="number" class="form-control" value="<?php echo e($assets->total); ?>" name="total" id="total">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="onhand" class="control-label col-sm-3 lb">On Hand</label>
                                    <div class="col-sm-8">
                                        <input type="number" class="form-control" value="<?php echo e($assets->onhand); ?>" name="onhand" id="onhand">
                                    </div>
                                </div>
                                
                                <div class="form-group row">
                                    <label for="description" class="control-label col-sm-3 lb">Description</label>
                                    <div class="col-sm-8">
                                         <textarea class="form-control" name="description" id="description"><?php echo e($assets->description); ?></textarea>
                                         <p>
                                            <br>
                                            <button class="btn btn-primary btn-flat" type="submit">Save</button>
                                            <button class="btn btn-danger btn-flat" type="reset">Cancel</button>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset("chosen/chosen.jquery.js")); ?>"></script>
    <script src="<?php echo e(asset("chosen/chosen.proto.js")); ?>"></script>

    <script>
        $(document).ready(function () {
            $("#siderbar li a").removeClass("current");
            $("#menu_asset").addClass("current");
        })
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.asset", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>