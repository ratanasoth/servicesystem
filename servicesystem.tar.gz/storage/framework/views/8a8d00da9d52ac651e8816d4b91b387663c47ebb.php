<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <strong>Create Customer</strong>&nbsp;&nbsp;
                    <a href="<?php echo e(url('/customer')); ?>" class="text-success"><i class="fa fa-arrow-left"></i> Back</a>

                </div>
                <div class="card-block">
                    <?php if(Session::has('sms')): ?>
                        <div class="alert alert-success" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <div>
                                <?php echo e(session('sms')); ?>

                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if(Session::has('sms1')): ?>
                        <div class="alert alert-danger" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <div>
                                <?php echo e(session('sms1')); ?>

                            </div>
                        </div>
                    <?php endif; ?>
                    <form action="<?php echo e(url('/customer/save')); ?>" class="form-horizontal" method="post" onsubmit="return confirm('Are you sure want to save?')">
                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group row">
                                    <label for="first_name" class="control-label col-sm-3 lb">First Name<span class="text-danger">*</span></label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" value="<?php echo e(old('first_name')); ?>" name="first_name" id="first_name" required>
                                    </div>
                                </div>
                               
                               <div class="form-group row">
                                    <label for="last_name" class="control-label col-sm-3 lb">Last Name<span class="text-danger">*</span></label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" value="<?php echo e(old('last_name')); ?>" name="last_name" id="last_name" required>
                                    </div>
                                </div>
                                 <div class="form-group row">
                                    <label for="gender" class="control-label col-sm-3 lb">Gender<span class="text-danger">*</span></label>
                                    <div class="col-sm-8">
                                        <select name="gender" id="gender" class="form-control">
                                            <option value="Male">Male</option>
                                            <option value="Female">Female</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="email" class="control-label col-sm-3 lb">Email</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" value="<?php echo e(old('email')); ?>" name="email" id="email">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="phone" class="control-label col-sm-3 lb">Phone</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" value="<?php echo e(old('phone')); ?>" name="phone" id="phone">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="address" class="control-label col-sm-3 lb">Address</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" value="<?php echo e(old('address')); ?>" name="address" id="address">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="username" class="control-label col-sm-3 lb">Username <span class="text-danger">*</span></label>
                                    <div class="col-sm-8">
                                        <input type="text" id="username" name="username" class="form-control" value="<?php echo e(old('username')); ?>" required>
                                         
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="password" class="control-label col-sm-3 lb">Password <span class="text-danger">*</span></label>
                                    <div class="col-sm-8">
                                        <input type="password" id="password" name="password" class="form-control" required>
                                         
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="cpassword" class="control-label col-sm-3 lb">Confirm cpassword <span class="text-danger">*</span></label>
                                    <div class="col-sm-8">
                                        <input type="password" id="cpassword" name="cpassword" class="form-control" required>
                                         
                                    </div>
                                </div>
                                 <div class="form-group row">
                                    <label for="company_name" class="control-label col-sm-3 lb">Company Name</label>
                                    <div class="col-sm-8">
                                        <input type="text" id="company_name" name="company_name" class="form-control" value="<?php echo e(old('company_name')); ?>">
                                         <p>
                                            <br>
                                            <button class="btn btn-primary btn-flat" type="submit">Save</button>
                                            <button class="btn btn-danger btn-flat" type="reset">Cancel</button>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset("chosen/chosen.jquery.js")); ?>"></script>
    <script src="<?php echo e(asset("chosen/chosen.proto.js")); ?>"></script>
    <script>
        $(document).ready(function () {
            $("#siderbar li a").removeClass("current");
            $("#customer").addClass("current");
            
        })
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.management", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>