<?php $__env->startSection('content'); ?>

<h1>hi</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(function(){
        $(".mn .nav-item").removeClass('active');
        $("#menu_home").addClass("active");
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.customer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>