<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <strong>Create Event</strong>&nbsp;&nbsp;
                    <a href="<?php echo e(url('/event')); ?>" class="text-success"><i class="fa fa-arrow-left"></i> Back</a>

                </div>
                <div class="card-block">
                    <?php if(Session::has('sms')): ?>
                        <div class="alert alert-success" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <div>
                                <?php echo e(session('sms')); ?>

                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if(Session::has('sms1')): ?>
                        <div class="alert alert-danger" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <div>
                                <?php echo e(session('sms1')); ?>

                            </div>
                        </div>
                    <?php endif; ?>
                    <form action="<?php echo e(url('/event/save')); ?>" class="form-horizontal" method="post" onsubmit="return confirm('Are you sure want to save?')">
                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group row">
                                    <label for="name" class="control-label col-sm-4 lb">Name<span class="text-danger">*</span></label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" value="<?php echo e(old('name')); ?>" name="name" id="name" required="true">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="location" class="control-label col-sm-4 lb">Location</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" value="<?php echo e(old('location')); ?>" name="location" id="location">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="event_date" class="control-label col-sm-4 lb">Event Date</label>
                                    <div class="col-sm-8">
                                        <input type="date" class="form-control" value="<?php echo e(old('event_date')); ?>" name="event_date" id="event_date">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="description" class="control-label col-sm-4 lb">Description</label>
                                    <div class="col-sm-8">
                                        <textarea id="description" name="description" class="form-control" rows="10"><?php echo e(old('description')); ?></textarea>
                                         <p>
                                            <br>
                                            <button class="btn btn-primary btn-flat" type="submit">Save</button>
                                            <button class="btn btn-danger btn-flat" type="reset">Cancel</button>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset("chosen/chosen.jquery.js")); ?>"></script>
    <script src="<?php echo e(asset("chosen/chosen.proto.js")); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment-with-locales.js"></script>
    <script src="https://cdn.rawgit.com/Eonasdan/bootstrap-datetimepicker/master/build/js/bootstrap-datetimepicker.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.rawgit.com/Eonasdan/bootstrap-datetimepicker/e8bddc60e73c1ec2475f827be36e1957af72e2ea/build/css/bootstrap-datetimepicker.css">
    <script>
        $(document).ready(function () {
            $("#siderbar li a").removeClass("current");
            $("#event").addClass("current");
        })
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.management", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>