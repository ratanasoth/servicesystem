<?php $__env->startSection("content"); ?>
    
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header text-bold">
                    <strong>Asset Management</strong>&nbsp;&nbsp;
                    <a href="<?php echo e(url('/asset/create')); ?>"><i class="fa fa-plus"></i> New</a>
                </div>
                <div class="card-block">
                    <table class="tbl">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Reference Code</th>
                            <th>Type</th>
                            <th>Warehouse</th>
                            <th>Balance Qty</th>
                            <th>Total Qty</th>
                            <th>Description</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                            $pagex = @$_GET['page'];
                            if(!$pagex)
                                $pagex = 1;
                            $i = 12 * ($pagex - 1) + 1;
                        ?>
                         <?php $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($asset->name); ?></td>
                                <td><?php echo e($asset->reference_code); ?></td>
                                <td><?php echo e($asset->type_name); ?></td>
                                <td><?php echo e($asset->warehouse_name); ?></td>
                                <td><?php echo e($asset->onhand); ?></td>
                                <td><?php echo e($asset->total); ?></td>
                                <td><?php echo e($asset->description); ?></td>
                                <td>
                                    <a href="<?php echo e(url('/asset/edit/'.$asset->id)); ?>" title="Edit"><i class="fa fa-edit text-success"></i></a>&nbsp;&nbsp
                                    <a href="<?php echo e(url('/asset/delete/'.$asset->id ."?page=".@$_GET["page"])); ?>" onclick="return confirm('Are you sure want to delete?')"
                                       title="Delete"><i class="fa fa-remove text-danger"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <nav>
                        <?php echo e($assets->links()); ?>

                    </nav>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function () {
            $("#siderbar li a").removeClass("current");
            $("#menu_asset").addClass("current");
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.asset", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>