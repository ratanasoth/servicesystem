<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header text-bold">
                    <div class="row">
                        <div class="col-sm-4">
                            <strong>Task Detail</strong>
                            &nbsp;&nbsp;
                            <a href="<?php echo e(url('/customer/task')); ?>" class="text-success"><i class="fa fa-arrow-left"></i> Back</a>
                        </div>
                        <div class="col-sm-5">

                        </div>
                    </div>

                </div>
                <div class="card-block">
                    <div class="form-group row">
                        <label class="control-label col-sm-2 lb">Task ID</label>
                        <div class="col-sm-7">
                            : <strong><?php echo e($task->id); ?></strong>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="control-label col-sm-2 lb">Task Title</label>
                        <div class="col-sm-7">
                            : <strong><?php echo e($task->title); ?></strong>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="control-label col-sm-2 lb">Severity</label>
                        <div class="col-sm-7">
                            : <strong><?php echo e($task->severity); ?></strong>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="control-label col-sm-2 lb">Deadline</label>
                        <div class="col-sm-7">
                            : <strong><?php echo e($task->deadline); ?></strong>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="control-label col-sm-2 lb">Handle Person</label>
                        <div class="col-sm-7">
                            : <strong><?php echo e($task->first_name); ?> <?php echo e($task->last_name); ?></strong>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="control-label col-sm-2 lb">Progression</label>
                        <div class="col-sm-7">
                            : <strong><?php echo e($task->progression); ?>%</strong>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="control-label col-sm-2 lb">Description</label>
                        <div class="col-sm-7">
                            : <strong><?php echo e($task->description); ?></strong>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function(){
            $(".mn .nav-item").removeClass('active');
            $("#menu_task").addClass("active");
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.customer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>