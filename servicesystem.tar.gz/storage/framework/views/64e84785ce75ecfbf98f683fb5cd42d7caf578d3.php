<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header text-bold">
                    <strong>Feedback Detail</strong>&nbsp;&nbsp;
                    <a href="<?php echo e(url('/feedback')); ?>" class="text-success"><i class="fa fa-arrow-left"></i> Back</a>
                    <a href="<?php echo e(url('/feedback/delete/'.$feedback->id)); ?>" class="text-danger" onclick="return confirm('You want to delete?')"><i class="fa fa-trash"></i> Delete</a>
                </div>
                <div class="card-block">
                   <div class="row">
                       <div class="col-sm-9">
                           <div class="form-group row">
                               <label class="control-label lb col-sm-2">Feedback ID</label>
                               <div class="col-sm-9">
                                   : <strong><?php echo e($feedback->id); ?></strong>
                               </div>
                           </div>
                           <div class="form-group row">
                               <label class="control-label lb col-sm-2">Subject</label>
                               <div class="col-sm-9">
                                   : <strong><?php echo e($feedback->subject); ?></strong>
                               </div>
                           </div>
                           <div class="form-group row">
                               <label class="control-label lb col-sm-2">Feedback To</label>
                               <div class="col-sm-9">
                                   : <strong><?php echo e($feedback->feedback_to); ?></strong>
                               </div>
                           </div>
                           <div class="form-group row">
                               <label class="control-label lb col-sm-2">Feedback By</label>
                               <div class="col-sm-9">
                                   : <strong><?php echo e($feedback->first_name); ?> <?php echo e($feedback->last_name); ?></strong>
                               </div>
                           </div>
                           <div class="form-group row">
                               <label class="control-label lb col-sm-2">Feedback Date</label>
                               <div class="col-sm-9">
                                   : <strong><?php echo e($feedback->create_at); ?></strong>
                               </div>
                           </div>
                           <div class="form-group row">
                               <label class="control-label lb col-sm-2">Description</label>
                               <div class="col-sm-9">
                                   : <strong><?php echo e($feedback->description); ?></strong>
                               </div>
                           </div>
                       </div>
                   </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function () {
            $("#siderbar li a").removeClass("current");
            $("#menu_feedback").addClass("current");
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.management", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>