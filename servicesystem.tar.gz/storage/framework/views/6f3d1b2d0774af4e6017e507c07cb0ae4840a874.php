<?php $__env->startSection("content"); ?>
    <div class="row">
        <div class="col-sm-12">
            <h2 class="text-primary">Core Management</h2>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.management", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>