<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <strong>Edit Task</strong>&nbsp;&nbsp;
                    <a href="<?php echo e(url('/task/create')); ?>"><i class="fa fa-plus"></i> New</a>
                    <a href="<?php echo e(url('/task')); ?>" class="text-success"><i class="fa fa-arrow-left"></i> Back</a>
                </div>
                <div class="card-block">
                    <?php if(Session::has('sms')): ?>
                        <div class="alert alert-success" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <div>
                                <?php echo e(session('sms')); ?>

                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if(Session::has('sms1')): ?>
                        <div class="alert alert-danger" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <div>
                                <?php echo e(session('sms1')); ?>

                            </div>
                        </div>
                    <?php endif; ?>
                    <form action="<?php echo e(url('/task/update')); ?>" class="form-horizontal" method="post" onsubmit="return confirm('Are you sure want to change?')">
                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group row">
                                    <label for="title" class="control-label col-sm-4 lb">Title <span class="text-danger">*</span></label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" value="<?php echo e($task->title); ?>" name="title" id="title" required="true">
                                        <input type="hidden" name="id" value="<?php echo e($task->id); ?>">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="severity" class="control-label col-sm-4 lb">Severity <span class="text-danger">*</span></label>
                                    <div class="col-sm-8">
                                        <select name="severity" id="severity" class="form-control">
                                            <?php $__currentLoopData = $severities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($s->name); ?>" <?php echo e($task->severity==$s->name?'selected':''); ?>><?php echo e($s->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="deadline" class="control-label col-sm-4 lb">Deadline <span class="text-danger">*</span></label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control datepicker-icon" value="<?php echo e($task->deadline); ?>" name="deadline" id="deadline" required="true">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="handler" class="control-label col-sm-4 lb">Handler</label>
                                    <div class="col-sm-8">
                                        <select name="handler" id="handler" class="form-control">
                                            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($e->id); ?>" <?php echo e($e->id==$task->handler?'selected':''); ?>><?php echo e($e->first_name); ?> <?php echo e($e->last_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="customer" class="control-label col-sm-4 lb">For Customer</label>
                                    <div class="col-sm-8">
                                        <select name="customer_id" id="customer_id" class="form-control chosen-select">
                                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($e->id); ?>" <?php echo e($e->id==$task->customer_id?'selected':''); ?>><?php echo e($e->first_name); ?> <?php echo e($e->last_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="progression" class="control-label col-sm-4 lb">Progression(%)</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="progression" name="progression" value="<?php echo e($task->progression); ?>">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="description" class="control-label col-sm-4 lb">Description <span class="text-danger">*</span></label>
                                    <div class="col-sm-8">
                                        <textarea id="description" name="description" class="form-control" rows="10" required="true"><?php echo e($task->description); ?></textarea>
                                         <p>
                                            <br>
                                            <button class="btn btn-primary btn-flat" type="submit">Save</button>
                                            <button class="btn btn-danger btn-flat" type="reset">Cancel</button>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset("chosen/chosen.jquery.js")); ?>"></script>
    <script src="<?php echo e(asset("chosen/chosen.proto.js")); ?>"></script>
    <script src="<?php echo e(asset('datepicker/js/bootstrap-datepicker.min.js')); ?>"></script>
    <script>
        $(document).ready(function () {
            $("#siderbar li a").removeClass("current");
            $("#task").addClass("current");
            $('#customer_id').chosen();
            $('#handler').chosen();
            $("#deadline").datepicker({
                orientation: 'bottom',
                format: 'yyyy-mm-dd',
                autoclose: true,
                todayHighlight: true,
                toggleActive: true
            });
        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.management", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>