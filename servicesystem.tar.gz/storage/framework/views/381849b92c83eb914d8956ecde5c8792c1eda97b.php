<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header text-bold">
                    <div class="row">
                        <div class="col-sm-4">
                            <strong>Feedback List</strong>
                            &nbsp;&nbsp;
                            <a href="<?php echo e(url('/customer/feedback/create')); ?>" class="text-primary"><i class="fa fa-plus"></i> New</a>
                        </div>
                        <div class="col-sm-5">
                            <form action="<?php echo e(url('/customer/feedback')); ?>" class="form-horizontal" method="get">
                                <div class="input-group"  style="margin-top: -9px;margin-bottom:3px">
                                    <input type="text" class="form-control" placeholder="Search for..." name="q" value="<?php echo e($q); ?>">
                                    <span class="input-group-btn">
                                            <button class="btn btn-primary" type="submit"><i class="fa fa-search"></i></button>
                                        </span>
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
                <div class="card-block">
                    <?php if(Session::has('sms')): ?>
                        <div class="alert alert-success" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <div>
                                <?php echo e(session('sms')); ?>

                            </div>
                        </div>
                    <?php endif; ?>
                    <table class="tbl">
                        <thead>
                        <tr>
                            <th>&numero;</th>
                            <th>Subject</th>
                            <th>Feedback To</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        $pagex = @$_GET['page'];
                        if(!$pagex)
                            $pagex = 1;
                        $i = 22 * ($pagex - 1) + 1;
                        ?>
                        <?php $__currentLoopData = $feedbacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($f->subject); ?></td>
                                <td><?php echo e($f->feedback_to); ?></td>
                                <td>
                                    <a href="<?php echo e(url('/customer/feedback/detail/'.$f->id)); ?>" class="btn btn-success">View</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <nav>
                        <?php echo e($feedbacks->links()); ?>

                    </nav>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function(){
            $(".mn .nav-item").removeClass('active');
            $("#menu_feedback").addClass("active");
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.customer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>