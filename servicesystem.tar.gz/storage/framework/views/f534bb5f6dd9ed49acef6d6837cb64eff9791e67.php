<?php $__env->startSection('content'); ?>
<div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header text-bold">
                   <div class="row">
                       <div class="col-sm-4">
                            <strong>Product List</strong>
                  
                       </div>
                       <div class="col-sm-5">
                            <form action="<?php echo e(url('/customer/product')); ?>" class="form-horizontal" method="get">
                                    <div class="input-group"  style="margin-top: -9px;margin-bottom:3px">
                                        <input type="text" class="form-control" placeholder="Search for..." name="q" value="<?php echo e($q); ?>">
                                        <span class="input-group-btn">
                                            <button class="btn btn-primary" type="submit"><i class="fa fa-search"></i></button>
                                        </span>
                                    </div>
                            </form>
                       </div>
                   </div>
               
                </div>
                <div class="card-block">
                    <table class="tbl">
                        <thead>
                        <tr>
                            <th>&numero;</th>
                            <th>Product Name</th>
                            <th>Type</th>
                            <th>Price</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                            $pagex = @$_GET['page'];
                            if(!$pagex)
                                $pagex = 1;
                            $i = 22 * ($pagex - 1) + 1;
                        ?>
                         <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($p->name); ?></td>
                                <td><?php echo e($p->type); ?></td>
                                <td><?php echo e($p->price); ?></td>
                                <td>
                                    <a href="<?php echo e(url('/customer/product/detail/'.$p->id)); ?>" class="btn btn-success">View</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <nav>
                        <?php echo e($products->links()); ?>

                    </nav>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(function(){
        $(".mn .nav-item").removeClass('active');
        $("#menu_product").addClass("active");
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.customer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>