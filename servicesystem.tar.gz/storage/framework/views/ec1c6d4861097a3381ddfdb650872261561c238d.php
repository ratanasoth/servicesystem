<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header text-bold">
                    <strong>Customer Request</strong>&nbsp;&nbsp;
                </div>
                <div class="card-block">
                    <table class="tbl">
                        <thead>
                        <tr>
                            <th>&numero;</th>
                            <th>Subject</th>
                            <th>Requester</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        $pagex = @$_GET['page'];
                        if(!$pagex)
                            $pagex = 1;
                        $i = 12 * ($pagex - 1) + 1;
                        ?>
                        <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($f->subject); ?></td>
                                <td><?php echo e($f->first_name); ?> <?php echo e($f->last_name); ?></td>
                                <td><?php echo e($f->request_date); ?></td>
                                <td>
                                    <a href="<?php echo e(url('/request/detail/'.$f->id)); ?>" class="btn btn-success">View</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <nav>
                        <?php echo e($requests->links()); ?>

                    </nav>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function () {
            $("#siderbar li a").removeClass("current");
            $("#menu_request").addClass("current");
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.management", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>