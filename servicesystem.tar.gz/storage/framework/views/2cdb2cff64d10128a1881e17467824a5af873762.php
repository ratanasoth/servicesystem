<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <strong>Asset check in</strong>&nbsp;&nbsp;
                    <a href="<?php echo e(url('/asset-out')); ?>" class="text-success"><i class="fa fa-arrow-left"></i> Back</a>

                </div>
                <div class="card-block">
                    <form action="<?php echo e(url('/asset-out/savein')); ?>" class="form-horizontal" method="post" onsubmit="return confirm('Are you sure want to return?')">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" value="<?php echo e($asset_out->id); ?>" name="id">
                        <div class="row">
                            <div class="col-sm-6">
                                <p class="text-primary">Asset Checkout Info</p>
                                <div class="form-group row">
                                    <label for="asset" class="control-label col-sm-3 lb"> Asset<span class="text-danger">*</span></label>
                                    <div class="col-sm-8">
                                        <select name="asset" id="asset" class="form-control" disabled>
                                            <?php $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($asset->id); ?>" <?php echo e($asset_out->asset_id==$asset->id?'selected':''); ?>><?php echo e($asset->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="quantity" class="control-label col-sm-3 lb">Quantity</label>
                                    <div class="col-sm-8">
                                        <input type="number" class="form-control" value="<?php echo e($asset_out->quantity); ?>" name="quantity" id="quantity" readonly>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="out_date" class="control-label col-sm-3 lb">Out Date</label>
                                    <div class="col-sm-8">
                                        <input type="date" class="form-control" name="out_date" id="out_date" value="<?php echo e($asset_out->out_date); ?>" readonly>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="return_date" class="control-label col-sm-3 lb">Return Date</label>
                                    <div class="col-sm-8">
                                        <input type="date" class="form-control" name="return_date" id="return_date" value="<?php echo e($asset_out->return_date); ?>" readonly>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="out_by" class="control-label col-sm-3 lb">Check Out By</label>
                                    <div class="col-sm-8">
                                        <select name="out_by" id="out_by" class="form-control" disabled>
                                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($user->id); ?>" <?php echo e($asset_out->out_by==$user->id?'selected':''); ?>><?php echo e($user->username); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="reason" class="control-label col-sm-3 lb">Reason</label>
                                    <div class="col-sm-8">
                                        <textarea class="form-control" name="reason" id="reason" readonly><?php echo e($asset_out->reason); ?></textarea>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="is_returned" class="control-label col-sm-3 lb">Return Status</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="is_returned" id="is_returned" value="<?php echo e($asset_out->is_returned); ?>" readonly>
                                        <br>

                                    </div>
                                </div>

                            </div>
                            <div class="col-sm-6">
                                <p>&nbsp;</p>
                                <div class="form-group row">
                                    <label for="rr" class="control-label col-sm-3 lb">Returned Qty</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" readonly value="<?php echo e($asset_out->return_qty); ?>">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="rr" class="control-label col-sm-3 lb">Due Qty</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" readonly value="<?php echo e($asset_out->due_qty); ?>">
                                    </div>
                                </div>
                                <br>
                                <p class="text-primary">Asset Check In</p>
                                <hr>
                                <div class="form-group row">
                                    <label for="return_qty" class="control-label col-sm-3 lb">Return Qty</label>
                                    <div class="col-sm-8">
                                        <input type="number" class="form-control" id="return_qty" name="return_qty">
                                        <input type="hidden" name="checkout_id" value="<?php echo e($asset_out->id); ?>">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="comment" class="control-label col-sm-3 lb">Comment</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="comment" name="comment">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="control-label col-sm-3 lb">&nbsp;</label>
                                    <div class="col-sm-8">
                                        <br>
                                        <button class="btn btn-primary btn-flat" type="submit">Submit Return</button>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <p class="text-primary">Check In History</p>
                        <table class="tbl">
                            <thead>
                                <tr>
                                    <th>&numero;</th>
                                    <th>Check In Date</th>
                                    <th>Check In By</th>
                                    <th>Quantity</th>
                                    <th>Comment</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php ($i=1); ?>
                            <?php $__currentLoopData = $ins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $in): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i++); ?></td>
                                    <td><?php echo e($in->in_date); ?></td>
                                    <td><?php echo e($in->first_name); ?> <?php echo e($in->last_name); ?></td>
                                    <td><?php echo e($in->quantity); ?></td>
                                    <td><?php echo e($in->comment); ?></td>
                                    <td>
                                        <a href="#" class="text-danger"><i class="fa fa-trash"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </form>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset("chosen/chosen.jquery.js")); ?>"></script>
    <script src="<?php echo e(asset("chosen/chosen.proto.js")); ?>"></script>
    <script>
        $(document).ready(function () {
            $("#siderbar li a").removeClass("current");
            $("#menu_asset_out").addClass("current");
            
        })
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.asset", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>