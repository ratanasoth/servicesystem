@extends('layouts.app')
@section('content')
    Hi
@endsection