@extends("layouts.payment")
@section("content")
    <div class="row">
        <div class="col-sm-12">
            <h2 class="text-primary">payment Management</h2>
        </div>
    </div>
@endsection