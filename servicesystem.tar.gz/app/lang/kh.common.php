<?php
$lb_new = "បង្កើតថ្មី";
$lb_id = "លេខID";
$lb_action = "សកម្មភាព";
$lb_edit = "កែប្រែ";
$lb_add = "បន្ថែម";
$lb_delete = "លុប";
$lb_view = "មើល";
$lb_list = "បញ្ជី";
$lb_save = "រក្សាទុក";
$lb_save_change = "រក្សាការផ្លាស់ប្តូរ";
$lb_cancel = "បោះបង់";
$lb_update = "កែប្រែ";
$lb_back = "ត្រលប់ក្រោយ";