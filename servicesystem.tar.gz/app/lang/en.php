<?php
$lb_dashboard = "Dashboard";
$lb_sale = "Sale";
$lb_pos = "POS";
$lb_purchase = "Purchase";
$lb_inventory = "Inventory";
$lb_accounting = "Accounting";
$lb_setting = "Settings";
$lb_help = "Help";
$lb_profile = "Profile";
$lb_rest_password = "Reset Password";
$lb_logout = "Login";
$lb_new = "New";
$lb_company = "Company";
$lb_branch = "Branch";
$lb_user = "Users";
$lb_user_role = "User Role";

