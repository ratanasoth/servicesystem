<?php
$lb_new = "New";
$lb_id = "ID";
$lb_action = "Actions";
$lb_edit = "Edit";
$lb_add = "Add";
$lb_delete = "Delete";
$lb_view = "View";
$lb_list = "List";
$lb_save = "Save";
$lb_save_change = "Save Changes";
$lb_cancel = "Cancel";
$lb_update = "Update";
$lb_back = "Back to List";